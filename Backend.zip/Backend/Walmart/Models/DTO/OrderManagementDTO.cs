﻿namespace Walmart.Models.DTO
{
    public class OrderManagementDTO
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ShippingAddress { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
        public string ProductName { get; set; } // Product name
        public string ImageURL { get; set; }

    }

    public class OrderManagedto
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ShippingAddress { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
    }
    public class ordernowdto
    {
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ShippingAddress { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }

        public string ProductName { get; set; } // Product name
        public string ImageURL { get; set; }

    }
    public class UpdateOrderDTO
    {
        public int Quantity { get; set; }
        public string OrderStatus { get; set; }
    }

    public class Checkout
    {
        public string ShippingAddress { get; set; }
        public string PaymentMode { get; set; }

    }
}