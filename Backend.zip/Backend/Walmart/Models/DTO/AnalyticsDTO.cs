﻿namespace Walmart.Models.DTO
{
    public class AnalyticsDTO
    {
        public int Users { get; set; }
        public int Products { get; set; }
        public int Orders { get; set; }
        public int Admins { get; set; }
    }
}