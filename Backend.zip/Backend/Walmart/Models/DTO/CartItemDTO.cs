﻿namespace Walmart.Models.DTO
{
    public class CartItemDTO
    {
        // ✅ Removed `UserID` since we get it from the token
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }
}