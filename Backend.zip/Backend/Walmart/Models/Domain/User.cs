﻿using System.ComponentModel.DataAnnotations;

namespace Walmart.Models.Domain
{
    public class User
    {
        [Key]
        public int UserID { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string ShippingAddress { get; set; } = string.Empty;
        public string PaymentDetails { get; set; } = string.Empty;
        public string Role { get; set; } = "User";
    }
}

