﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Walmart.Models.Domain
{
    public class CartItem
    {
        [Key]
        public int CartItemID { get; set; }

        [ForeignKey("User")]
        public int UserID { get; set; } // ✅ UserID will be set automatically from the JWT token
        [JsonIgnore]
        public User User { get; set; } // ✅ Navigation property for User

        [ForeignKey("ProductManagement")]
        public int ProductID { get; set; }
        public ProductManagement ProductManagement { get; set; } // ✅ Navigation property for Product

        public int Quantity { get; set; } // ✅ Item quantity
        public decimal TotalPrice { get; set; } // ✅ Total price (Quantity * Product Price)

        public string ImageURL { get; set; } // ✅ Store product image URL
    }
}
