﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;
using System.Security.Claims;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = "User")]
public class CartItemController : ControllerBase
{
    private readonly ICartItemRepository _cartItemRepository;
    private readonly IMapper _mapper;
    private readonly ILogger<CartItemController> _logger;

    public CartItemController(ICartItemRepository cartItemRepository, IMapper mapper, ILogger<CartItemController> logger)
    {
        _cartItemRepository = cartItemRepository;
        _mapper = mapper;
        _logger = logger;
    }

    [HttpPost("Add_Into_Cart")]
    public async Task<IActionResult> Post([FromBody] CartItemDTO cartItemRequest)
    {
        try
        {
            var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(currentUserId)) return Unauthorized("User ID claim not found.");
            if (!int.TryParse(currentUserId, out int userId)) return BadRequest("Invalid user ID format.");

            var product = await _cartItemRepository.GetProductByIdAsync(cartItemRequest.ProductID);
            if (product == null) return NotFound($"Product with ID {cartItemRequest.ProductID} not found.");

            var cartItem = new CartItem
            {
                UserID = userId,
                ProductID = cartItemRequest.ProductID,
                Quantity = cartItemRequest.Quantity,
                TotalPrice = cartItemRequest.Quantity * product.Price,
                ProductManagement = product,
                ImageURL = product.ImageURL // ✅ Automatically set ImageURL
            };

            await _cartItemRepository.AddCartItemAsync(cartItem);
            var cartItemResponse = _mapper.Map<CartItemResponseDTO>(cartItem);

            return CreatedAtAction(nameof(GetUserCart), new { userId }, cartItemResponse);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while adding a cart item.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpGet("Your_Cart")]
    public async Task<IActionResult> GetUserCart()
    {
        try
        {
            var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(currentUserId)) return Unauthorized("User ID claim not found.");
            if (!int.TryParse(currentUserId, out int userId)) return BadRequest("Invalid user ID format.");

            var cartItems = await _cartItemRepository.GetCartItemsByUserIdAsync(userId);
            if (cartItems == null || !cartItems.Any()) return NotFound($"No cart items found for User ID {userId}.");

            var cartItemDetailsDTOs = cartItems.Select(cartItem => new CartItemDetailsDTO
            {
                CartItemID = cartItem.CartItemID,
                ProductID = cartItem.ProductID,
                Quantity = cartItem.Quantity,
                TotalPrice = cartItem.TotalPrice,
                ImageURL = cartItem.ImageURL,
                ProductName = cartItem.ProductManagement?.Name // ✅ Fetch product name
            }).ToList();

            return Ok(cartItemDetailsDTOs);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while fetching cart items.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpPut("Edit_Your_Cart")]
    public async Task<IActionResult> UpdateCartItem(int id, [FromBody] CartItemDTO cartItemRequest)
    {
        try
        {
            var existingCartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
            if (existingCartItem == null) return NotFound($"CartItem with ID {id} not found.");

            var product = await _cartItemRepository.GetProductByIdAsync(cartItemRequest.ProductID);
            if (product == null) return NotFound($"Product with ID {cartItemRequest.ProductID} not found.");

            existingCartItem.Quantity = cartItemRequest.Quantity;
            existingCartItem.TotalPrice = cartItemRequest.Quantity * product.Price;
            existingCartItem.ImageURL = product.ImageURL; // ✅ Ensure ImageURL is updated if necessary

            await _cartItemRepository.UpdateCartItemAsync(existingCartItem);
            var updatedCartItemResponse = _mapper.Map<CartItemResponseDTO>(existingCartItem);

            return Ok(updatedCartItemResponse);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while updating the cart item.");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpDelete("Delete_the_Cart")]
    public async Task<IActionResult> RemoveCartItem(int id)
    {
        try
        {
            var cartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
            if (cartItem == null) return NotFound($"CartItem with ID {id} not found.");

            await _cartItemRepository.DeleteCartItemAsync(id);
            return Ok("Deleted Successfully!");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while deleting the cart item.");
            return StatusCode(500, "Internal server error");
        }
    }
}
