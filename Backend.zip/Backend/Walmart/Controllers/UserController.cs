﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<UserController> _logger;

        public UserController(IUserRepository userRepository, IMapper mapper, ILogger<UserController> logger)
        {
            _userRepository = userRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [Authorize(Roles = "Admin,User")]
        [HttpGet("User_Account")]
        public async Task<IActionResult> GetUserAccount()
        {
            try
            {
                // Extract user ID from claims
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(currentUserId))
                {
                    return Unauthorized("User ID claim not found.");
                }

                if (!int.TryParse(currentUserId, out int userId))
                {
                    return BadRequest("Invalid user ID format.");
                }

                // Fetch user details using the extracted user ID
                var user = await _userRepository.GetUserByIdAsync(userId);
                if (user == null)
                {
                    return NotFound($"User with ID {userId} not found.");
                }

                var userDTO = _mapper.Map<UserDTO>(user);

                return Ok(userDTO);
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                Console.WriteLine($"Error: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }



        [Authorize(Roles = "User")]
        [HttpPut("Edit_Account")]
        public async Task<IActionResult> Update([FromBody] UserDTO userRequest)
        {
            try
            {
                // Extract user ID from claims
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(currentUserId))
                {
                    return Unauthorized("User ID claim not found.");
                }

                if (!int.TryParse(currentUserId, out int userId))
                {
                    return BadRequest("Invalid user ID format.");
                }

                // Fetch existing user details using the extracted user ID
                var existingUser = await _userRepository.GetUserByIdAsync(userId);
                if (existingUser == null)
                {
                    return NotFound($"User with ID {userId} not found.");
                }

                // Map the incoming userRequest to the existing user entity
                _mapper.Map(userRequest, existingUser);

                // Hash the password before storing it
                if (!string.IsNullOrEmpty(userRequest.Password))
                {
                    var passwordHasher = new PasswordHasher<User>();
                    existingUser.Password = passwordHasher.HashPassword(existingUser, userRequest.Password);
                }

                // Update the user details in the repository
                await _userRepository.UpdateUserAsync(existingUser);

                return Ok(existingUser);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }



        [Authorize(Roles = "Admin,User")]
        [HttpDelete("Delete_Account")]
        public async Task<IActionResult> Delete()
        {
            try
            {
                // Extract user ID from claims
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(currentUserId))
                {
                    return Unauthorized("User ID claim not found.");
                }

                if (!int.TryParse(currentUserId, out int userId))
                {
                    return BadRequest("Invalid user ID format.");
                }

                // Fetch existing user details using the extracted user ID
                var user = await _userRepository.GetUserByIdAsync(userId);
                if (user == null)
                {
                    return NotFound($"User with ID {userId} not found.");
                }

                // Delete the user
                await _userRepository.DeleteUserAsync(userId);

                return Ok("Deleted Successfully!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }
        [Authorize(Roles = "Admin")]
        [HttpDelete("Delete_Account_by_admin/{id}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            try
            {
                var user = await _userRepository.GetUserByIdAsync(id);
                if (user == null)
                {
                    return NotFound($"User with ID {id} not found.");
                }

                await _userRepository.DeleteUserAsync(id);

                return Ok("Deleted Successfully!");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the user account with ID {UserID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
