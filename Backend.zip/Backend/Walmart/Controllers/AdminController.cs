﻿using AutoMapper;

using Microsoft.AspNetCore.Mvc;

using System.Threading.Tasks;

using Walmart.Models.DTO;

using Walmart.Repositories.Interface;

using Microsoft.AspNetCore.Authorization;

using Walmart.Models.Domain;

using Walmart.Repositories.Repository;

using System;

namespace Walmart.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    [Authorize(Roles = "Admin")]

    public class AdminController : ControllerBase

    {

        private readonly IAdminRepository _adminRepository;

        private readonly IUserRepository _userRepository;

        private readonly IProductManagementRepository _productRepository;

        private readonly IOrderManagementRepository _orderRepository;

        private readonly IMapper _mapper;

        public AdminController(

            IAdminRepository adminRepository,

            IUserRepository userRepository,

            IProductManagementRepository productRepository,

            IOrderManagementRepository orderRepository,

            IMapper mapper)

        {

            _adminRepository = adminRepository;

            _userRepository = userRepository;

            _productRepository = productRepository;

            _orderRepository = orderRepository;

            _mapper = mapper;

        }

        [HttpGet("Get_All_Users")]

        public async Task<IActionResult> GetUsers()

        {

            try

            {

                var users = await _userRepository.GetAllUsersAsync();

                var userDTOs = _mapper.Map<IEnumerable<UserAdminDto>>(users); // Map to DTOs

                return Ok(userDTOs);

            }

            catch (Exception ex)

            {

                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

        [HttpGet("Get_All_Products")]

        public async Task<IActionResult> GetProducts()

        {

            try

            {

                var products = await _productRepository.GetAllProductsAsync();

                var productDTOs = _mapper.Map<IEnumerable<ProductAdminDto>>(products); // Map to DTOs

                return Ok(productDTOs);

            }

            catch (Exception ex)

            {

                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

        [HttpGet("Get_All_Orders")]

        public async Task<IActionResult> GetOrders()

        {

            try

            {

                var orders = await _orderRepository.GetAllOrdersAsync();

                var orderDTOs = _mapper.Map<IEnumerable<OrderManagedto>>(orders); // Map to DTOs

                return Ok(orderDTOs);

            }

            catch (Exception ex)

            {

                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

        [HttpGet("Get_All_Admins")]

        public async Task<IActionResult> GetAdmins()

        {

            try

            {

                var admins = await _adminRepository.GetAllAdminsAsync();

                var adminDTOs = _mapper.Map<IEnumerable<AdminDto>>(admins); // Map to DTOs

                return Ok(adminDTOs);

            }

            catch (Exception ex)

            {

                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

        [HttpGet("Get_Orders_Of_User")]

        public async Task<IActionResult> GetOrdersByUserId(int userId)

        {

            try

            {

                var orders = await _orderRepository.GetAllOrdersAsync();

                var userOrders = orders.Where(o => o.UserID == userId).ToList();

                if (userOrders == null || !userOrders.Any())

                {

                    return NotFound($"No orders found for User ID {userId}.");

                }

                // Map list of OrderManagement to list of OrderManagementDTO

                var orderDTOs = _mapper.Map<IEnumerable<OrderManagementDTO>>(userOrders);

                return Ok(orderDTOs);

            }

            catch (Exception ex)

            {

                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

        [HttpGet("Analytics")]

        public async Task<IActionResult> DataAnalytics()

        {

            try

            {

                var adminCount = (await _adminRepository.GetAllAdminsAsync()).Count();

                var productCount = (await _productRepository.GetAllProductsAsync()).Count();

                var orderCount = (await _orderRepository.GetAllOrdersAsync()).Count();

                var userCount = (await _userRepository.GetAllUsersAsync()).Count();

                var analyticsDTO = new AnalyticsDTO

                {

                    Users = userCount,

                    Products = productCount,

                    Orders = orderCount,

                    Admins = adminCount,

                };

                return Ok(analyticsDTO);

            }

            catch (Exception ex)

            {

                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

    }

}

