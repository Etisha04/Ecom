﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Walmart.Data;
using Walmart.Models.Domain;
using Walmart.Repositories.Interface;

namespace Walmart.Repositories.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly HeroDbContext _dbContext;

        public AdminRepository(HeroDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Admin>> GetAllAdminsAsync()
        {
            return await _dbContext.Admins.ToListAsync();
        }

        public async Task<Admin> GetAdminByIdAsync(int id)
        {
            return await _dbContext.Admins.FindAsync(id);
        }

        public async Task<Admin> GetAdminByEmailAsync(string email)
        {
            return await _dbContext.Admins.FirstOrDefaultAsync(a => a.Email == email);
        }

        public async Task AddAdminAsync(Admin admin)
        {
            await _dbContext.Admins.AddAsync(admin);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateAdminAsync(Admin admin)
        {
            _dbContext.Admins.Update(admin);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAdminAsync(int id)
        {
            var admin = await _dbContext.Admins.FindAsync(id);
            if (admin != null)
            {
                _dbContext.Admins.Remove(admin);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
